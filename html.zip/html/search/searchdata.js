var indexSectionsWithContent =
{
  0: "acfgimprstvxy",
  1: "cmv",
  2: "acgimrsv",
  3: "cfgtvxy",
  4: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Funções",
  3: "Variáveis",
  4: "Páginas"
};

