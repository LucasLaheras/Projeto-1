var searchData=
[
  ['getadcionacaminhao',['getAdcionaCaminhao',['../class_mundo.html#acc3a26a242cfe494033e8f36bad5648b',1,'Mundo']]],
  ['getadcionacarro',['getAdcionaCarro',['../class_mundo.html#ac4e9fdfe30a81bf82f1eedf4b990c96a',1,'Mundo']]],
  ['getadcionamoto',['getAdcionaMoto',['../class_mundo.html#a7fb9d6c8df95d88eae88ed3d15f0195e',1,'Mundo']]],
  ['getcilindradas',['getCilindradas',['../class_moto.html#aceb2f04f9b41595a26c57963bc115c61',1,'Moto']]],
  ['getcor',['getCor',['../class_veiculo.html#a4fed5f48e6ddcf1c3e9a5a5ff9ba3067',1,'Veiculo']]],
  ['getdeletacaminhao',['getDeletaCaminhao',['../class_mundo.html#ad2eb05e9209d3c30bf0514f0a24a502a',1,'Mundo']]],
  ['getdeletacarro',['getDeletaCarro',['../class_mundo.html#a999bc3ec64b4daed18ab28ad6657c56c',1,'Mundo']]],
  ['getdeletamoto',['getDeletaMoto',['../class_mundo.html#a80d1b5b8e454f2d218c3dbfb6e344d1a',1,'Mundo']]],
  ['gettipo',['getTipo',['../class_carro.html#a44c3fde04be3cc309b9eac8b826c1560',1,'Carro']]],
  ['gettoneladas',['getToneladas',['../class_caminhao.html#a0d70fd366dda14b15b69fea764055001',1,'Caminhao']]],
  ['getvelocidade',['getVelocidade',['../class_veiculo.html#a29ede179017c05f28aebf02922a5478b',1,'Veiculo']]],
  ['getx',['getX',['../class_veiculo.html#a235b29e1e25ec8c769b20fb2aeba8404',1,'Veiculo']]],
  ['gety',['getY',['../class_veiculo.html#a06b2a923e51186673a016f75d10363d3',1,'Veiculo']]]
];
