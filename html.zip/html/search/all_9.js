var searchData=
[
  ['toneladas',['toneladas',['../class_caminhao.html#a76b6b066d32dac55e7b6e6669162b94e',1,'Caminhao']]]
];
